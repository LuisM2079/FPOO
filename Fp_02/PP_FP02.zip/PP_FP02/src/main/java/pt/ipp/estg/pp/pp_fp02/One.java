/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pt.ipp.estg.pp.pp_fp02;

/**
 *
 * @author luism
 */
public class One {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char[] sentence = {'e', 'u', ' ', 's', 'o', 'u', ' ',
            'a', 'l', 'u', 'n', 'o', ' ', 'd', 'a', ' ',
            'E', 'S', 'T', 'G', '.', '\n'};
        
        for (int i = 0; i < sentence.length; i++) {
            System.out.print(sentence[i]);
        }
    }
    
}
