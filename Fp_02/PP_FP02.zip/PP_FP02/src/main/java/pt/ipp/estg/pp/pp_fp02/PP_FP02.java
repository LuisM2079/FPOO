/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pt.ipp.estg.pp.pp_fp02;

/**
 *
 * @author luism
 */
public class PP_FP02 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
